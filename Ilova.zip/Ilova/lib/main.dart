import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: ColorPickerApp(),
  ));
}

class ColorPickerApp extends StatefulWidget {
  const ColorPickerApp({Key? key}) : super(key: key);

  @override
  State<ColorPickerApp> createState() => _ColorPickerAppState();
}

class _ColorPickerAppState extends State<ColorPickerApp> {
  Color _pickerColor = Colors.blue; // Rang tanlagichdagi rang
  Color _currentColor = Colors.blue; // Hozirgi fon rangi

  // Rang o‘zgarishini boshqarish
  void _changeColor(Color color) {
    setState(() {
      _pickerColor = color;
    });
  }

  // Rang tanlash oynasini ko‘rsatish
  void _showColorPicker() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Rang tanlang'),
          content: SingleChildScrollView(
            child: ColorPicker(
              pickerColor: _pickerColor,
              onColorChanged: _changeColor,
              enableAlpha: false,
              displayThumbColor: true,
              paletteType: PaletteType.hsv,
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              child: const Text('Qo‘llash'),
              onPressed: () {
                setState(() {
                  _currentColor = _pickerColor;
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _currentColor,
      appBar: AppBar(
        title: const Text('Rang tanlash ilovasi'),
        backgroundColor: _currentColor,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 200,
              height: 200,
              color: _currentColor,
              alignment: Alignment.center,
              child: Text(
                '#${_currentColor.value.toRadixString(16).padLeft(8, '0').toUpperCase()}',
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _showColorPicker,
              child: const Text('Rang tanlash'),
            ),
          ],
        ),
      ),
    );
  }
}
